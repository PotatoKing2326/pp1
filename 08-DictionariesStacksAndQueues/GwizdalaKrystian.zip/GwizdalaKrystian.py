import turtle
t = turtle
t.speed(50)

def Circle(r):
    t.fillcolor("grey")
    t.begin_fill() 
    t.circle(r)
    t.end_fill()

def Rhombus(a):
    if a < 100:
        t.fillcolor("black")
    else:
        t.fillcolor("red")
    t.begin_fill()
    t.right(45)
    t.fd(a)
    t.left(90)
    t.fd(a)
    t.left(90)
    t.fd(a)
    t.left(90)
    t.fd(a)
    t.end_fill()

def hexagon():
    t.fillcolor("lightgreen")
    t.begin_fill()
    for i in range(6):
        t.fd(30)
        t.left(300)
    t.end_fill()
def Semicircle(r):
    t.fillcolor("blue")
    t.begin_fill()
    t.circle(r, 180)
    t.left(90)
    t.fd(r*2)
    t.end_fill()

def Trapeze():
    t.fillcolor("green")
    t.begin_fill()
    t.fd(30)
    t.right(60)
    t.fd(30)
    t.right(120)
    t.fd(60)
    t.right(120)
    t.fd(30)
    t.right(60)
    t.end_fill()

def name():
    t.penup()
    t.goto(400,500)
    t.pendown()
    t.color("black")
    
    t.fd(20)
    t.bk(10)
    t.right(45)
    t.fd(13)
    t.bk(13)
    t.left(90)
    t.bk(13)
    t.fd(13)
    t.right(45)
    t.bk(10)

    t.penup()
    t.setx(420)
    t.pendown()
    
Circle(90)
t.right(90)
Rhombus(100)

t.penup()
t.goto(-85, -55)
t.pendown()
Circle(30)

t.penup()
t.goto(130, -55)
t.pendown()
Circle(30)

t.penup()
t.goto(20, -171)
t.right(135)
t.fd(30)
t.pendown()
Circle(30)

t.penup()
t.bk(100)
t.pendown()
Circle(30)

t.penup()
t.back(15)
t.pendown()
hexagon()

t.penup()
t.fd(100)
t.pendown()
hexagon()

t.penup()
t.goto(100, -106)
t.pendown()
hexagon()

t.penup()
t.setx(-130)
t.pendown()
hexagon()

y = -30
a = 55
for repeat in range(4):
    t.penup()
    t.goto(0, y)
    t.right(90)
    t.pendown()
    Rhombus(a)
    t.left(45)
    y = y - 35
    a = a - 5

t.penup()
t.goto(50, 80)
t.pendown()
Semicircle(15)

t.penup()
t.bk(30)
t.right(90)
t.fd(10)
t.pendown()
Semicircle(15)

t.penup()
t.goto(-50, 110)
t.left(90)
t.pendown()
Semicircle(15)

t.penup()
t.bk(30)
t.right(90)
t.fd(10)
t.pendown()
Semicircle(15)

t.penup()
t.goto(-45, 55)
t.pendown()
Semicircle(45)

t.penup()
t.goto(-64, -225)
t.right(180)
t.pendown()
Trapeze()

t.penup()
t.fd(100)
t.pendown()
Trapeze()

t.penup()
t.goto(90, 75)
t.left(90)
t.pendown()
Trapeze()

t.penup()
t.goto(-90, 105)
t.right(180)
t.pendown()
Trapeze()

t.penup()
t.goto(-15, 220)
t.left(90)
t.pendown()
hexagon()

t.penup()
t.fd(30)
t.right(180)
t.pendown()
Trapeze()

t.right(90)
name()

i = input()